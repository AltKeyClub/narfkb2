#pragma once

// #define HAL_USE_SERIAL TRUE

#include_next <halconf.h>
