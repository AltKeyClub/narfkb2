// Copyright 2022 Nick Brassel (@tzarc)
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

// #define LV_DITHER_GRADIENT 1

#include_next <lv_conf.h>

// #undef LV_COLOR_16_SWAP
// #define LV_COLOR_16_SWAP 0
