---
name: Blank issue
about: If you're 100% sure that you don't need one of the other issue templates, use
  this one instead.
title: ''
labels: help wanted, question
assignees: ''

---


