# テストとデバッグ

<!---
  grep --no-filename "^[ ]*git diff" docs/ja/*.md | sh
  original document: 0.12.45:docs/newbs_testing_debugging.md
  git diff 0.12.45 HEAD -- docs/newbs_testing_debugging.md | cat
-->

## テスト

[ここに移動しました](ja/faq_misc.md#testing)

## デバッグ :id=debugging

[ここに移動しました](ja/faq_debug.md#debugging)
