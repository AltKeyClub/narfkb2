#include QMK_KEYBOARD_H
extern rgblight_config_t rgblight_config;


enum layers { BASE = 0, RAISE, LOWER, SET };

#if defined(ENCODER_MAP_ENABLE)
const uint16_t PROGMEM encoder_map[][NUM_ENCODERS][NUM_DIRECTIONS] = {
    [BASE] =   { ENCODER_CCW_CW(KC_VOLD, KC_VOLU), ENCODER_CCW_CW(KC_MS_WH_UP, KC_MS_WH_DOWN)  },
    [LOWER] =  { ENCODER_CCW_CW(RGB_HUD, RGB_HUI), ENCODER_CCW_CW(RGB_SAD, RGB_SAI)  },
    [RAISE] =  { ENCODER_CCW_CW(RGB_VAD, RGB_VAI), ENCODER_CCW_CW(RGB_SPD, RGB_SPI)  },
    [SET] = { ENCODER_CCW_CW(RGB_RMOD, RGB_MOD), ENCODER_CCW_CW(KC_RIGHT, KC_LEFT) },
};
#endif


const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [BASE] = LAYOUT(
        _______,  _______,    _______,    _______,    _______,    _______,                                                       _______,    _______,    _______,    _______,    _______,     _______,
        _______,  _______,    _______,    _______,    _______,    _______, _______,                                     _______, _______,    _______,    _______,    _______,   _______, _______,
        _______, _______,    _______,    _______,    _______,    _______, _______, _______, _______, _______, _______, _______, _______,    _______,    _______, _______,  _______,  KC_ENT,
                                   _______, _______, KC_SPC,                                                     KC_SPC,  _______, _______
    ),
    [RAISE] = LAYOUT(
        _______,  _______,    _______,    _______,    _______,    _______,                                                       _______,    _______,    _______,    _______,    _______,     _______,
        _______,  _______,    _______,    _______,    _______,    _______, _______,                                     _______, _______,    _______,    _______,    _______,   _______, _______,
        _______, _______,    _______,    _______,    _______,    _______, _______, _______, _______, _______, _______, _______, _______,    _______,    _______, _______,  _______,  KC_ENT,
                                   _______, _______, KC_SPC,                                                     KC_SPC,  _______, _______
    ),
    [LOWER] = LAYOUT(
        _______,  _______,    _______,    _______,    _______,    _______,                                                       _______,    _______,    _______,    _______,    _______,     _______,
        _______,  _______,    _______,    _______,    _______,    _______, _______,                                     _______, _______,    _______,    _______,    _______,   _______, _______,
        _______, _______,    _______,    _______,    _______,    _______, _______, _______, _______, _______, _______, _______, _______,    _______,    _______, _______,  _______,  KC_ENT,
                                   _______, _______, KC_SPC,                                                     KC_SPC,  _______, _______
    ),
    [SET] = LAYOUT(
        _______,  _______,    _______,    _______,    _______,    _______,                                                       _______,    _______,    _______,    _______,    _______,     _______,
        _______,  _______,    _______,    _______,    _______,    _______, _______,                                     _______, _______,    _______,    _______,    _______,   _______, _______,
        _______, _______,    _______,    _______,    _______,    _______, _______, _______, _______, _______, _______, _______, _______,    _______,    _______, _______,  _______,  KC_ENT,
                                   _______, _______, KC_SPC,                                                     KC_SPC,  _______, _______
    )
};

//Capas RGB (El led 0 es el del controlador izquierdo y el 1 el del lado derecho)
const rgblight_segment_t PROGMEM my_base[] = RGBLIGHT_LAYER_SEGMENTS(
    {0,2,HSV_WHITE} //Se enciende en color blanco 2 leds a partir del led 0
);

const rgblight_segment_t PROGMEM my_raise[] = RGBLIGHT_LAYER_SEGMENTS(
    {0,1,HSV_BLUE} //Se enciende en color azul 1 led a partir del led 1
);

const rgblight_segment_t PROGMEM my_lower[] = RGBLIGHT_LAYER_SEGMENTS(
    {1,1,HSV_RED}
);

const rgblight_segment_t PROGMEM my_set[] = RGBLIGHT_LAYER_SEGMENTS(
    {0,2,HSV_YELLOW}
);
const rgblight_segment_t PROGMEM my_capslock[] = RGBLIGHT_LAYER_SEGMENTS(
    {0,1,HSV_PURPLE}
);


const rgblight_segment_t* const PROGMEM my_rgb_layers[] = RGBLIGHT_LAYERS_LIST(
    my_base,
    my_raise,
    my_lower,
    my_set,
    my_capslock
);

void keyboard_post_init_user(void) {
    rgblight_layers = my_rgb_layers;
   };

//Función booleana para encender o apagar el indicador de CAPS LOCK
bool led_update_user(led_t led_state) {
	rgblight_set_layer_state(4, led_state.caps_lock);
	return true;

}

 //Capa RGB default BASE en color blanco
layer_state_t default_layer_state_set_user(layer_state_t state) {
    rgblight_set_layer_state(0, layer_state_cmp(state, BASE));
    return state;
}

//Resto de capas RGB en distintos colores
layer_state_t layer_state_set_user(layer_state_t state) {
    rgblight_set_layer_state(1, layer_state_cmp(state, RAISE));
    rgblight_set_layer_state(2, layer_state_cmp(state, LOWER));
    rgblight_set_layer_state(3, layer_state_cmp(state, SET));
    return state;
}

