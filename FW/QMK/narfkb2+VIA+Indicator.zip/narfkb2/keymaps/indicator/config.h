

#pragma once

// Set number of layers for VIA (+30 per layer)
// #define DYNAMIC_KEYMAP_LAYER_COUNT 8

#define WS2812_DI_PIN GP16
#define RGB_DI_PIN GP16

#define RGBLED_NUM 2
#define RGBLED_SPLIT {1,1}
#define RGBLIGHT_LIMIT_VAL 40 //Power draw may still exceed the USB limitations of 0.6A at max brightness with white colour with this setting.
//#define RGBLIGHT_LAYERS //Enable layer light indicators. Not required as updates are done in layer_state_set_user and led_update_user (+588).
//#define RGBLIGHT_SLEEP //Turn off LEDs when computer sleeping (+72)
#define RGBLIGHT_LAYERS
#define RGBLIGHT_LAYERS_OVERRIDE_RGB_OFF



